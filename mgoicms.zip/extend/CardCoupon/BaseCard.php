<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/12
 * Time: 15:18
 */

namespace cardCoupon;


class BaseCard
{

}