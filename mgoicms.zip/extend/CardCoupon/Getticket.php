<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/7
 * Time: 20:26
 */

namespace cardCoupon;


use app\api\service\AccessToken;
use think\Exception;

class Getticket
{
    private $ticket_url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=%s&type=wx_card";
    const TICKET_CACHED_KEY = 'ticket';
    const TICKET_EXPIRE_IN = 7000;


    public function __construct()
    {
        $accessToken = new \cardCoupon\AccessToken();
        $token = $accessToken->get();
        $this->ticket_url = sprintf($this->ticket_url,$token);
    }

    public function getTicket(){
        $ticket = $this->getTicketFromCache();
        if(!$ticket){
            return $this->getFromWxService();
        }
        return $ticket;
    }

    private function getFromWxService(){
        $ticket = curl_get($this->ticket_url);
        $ticket = json_decode($ticket, true);
        if(!$ticket){
            throw new Exception('ticket获取异常');
        }
        if($ticket['errcode'] != 0){
            throw new Exception($ticket['errmsg']);
        }
        $this->saveToCache($ticket['ticket']);
        return $ticket['ticket'];
    }

    private function getTicketFromCache(){
        $ticket = cache(self::TICKET_CACHED_KEY);
        if(!$ticket){
            return null;
        }
        return $ticket;
    }

    private function saveToCache($val){
        cache(self::TICKET_CACHED_KEY, $val, self::TICKET_EXPIRE_IN);
    }

}