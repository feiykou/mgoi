<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/12
 * Time: 15:16
 */

namespace cardCoupon;


class CardApi
{

    public function get(){
        // 获取api_ticket
        $ticket = $this->getTicket();

        $param = [
            'api_ticket' => $ticket,
            'timestamp' => time(),
            'nonce_str' => getRandChar(32),
            'card_id' => 'pp0BU0RRi4iGSISJynRmc8Pmk5II'
        ];

        $signature = $this->getSignature($param);
        $data = [];
        $data['api_ticket'] = $param['api_ticket'];
        $data['timestamp'] = $param['timestamp'];
        $data['signature'] = $signature;
        $data['nonce_str'] = $param['nonce_str'];
        $data['card_id'] = $param['card_id'];

        return $data;
    }



    // 生成签名
    private function getSignature($params){
        sort($params,2);
//        $str = '';
//        foreach ($params as $key => $val){
//            $str .= $key . '=' . $val . '&';
//        }
//        $str = trim($str,'&');
        return sha1(implode($params));
    }

    // 获取api_ticket
    private function getTicket(){
        $getTicket = new Getticket();
        return $getTicket->getTicket();
    }

}