<?php
namespace catetree;
class Catetree {
    
    public function catetree($cateRes){
        return $this->sort(false, $cateRes);
    }

    public function sort($mark, $cateRes,$pid=0,$level=0){

        static $arr=array();
        if(!$mark) $arr = [];
        foreach ($cateRes as $k => $v) {
            if($v['pid']==$pid){
                $v['level']=$level;
                $arr[]=$v;
                unset($cateRes[$k]);
                $this->sort(true,$cateRes,$v['id'],$level+1);
            }
        }

        return $arr;
    }

    // 树结构
    public function generateTree($data){
        // 构造数据
        $items = [];
        foreach ($data as $val){
            $items[$val['id']] = $val;
        }

        // 遍历数据，生成数据结构
        $tree = [];
        foreach ($items as $key => $val){
            if(isset($items[$val['pid']])){
                $items[$val['pid']]['son'][] = &$items[$key];
            }else{
                $tree[] = &$items[$key];
            }
        }
        return $tree;
    }

   //获取子栏目id
   public function childrenids($cateid,$obj){
        $data=$obj->field('id,pid')->select();
        return $this->_childrenids($data,$cateid,TRUE);
   }

   private function _childrenids($data,$cateid,$clear=FALSE){
        static $arr=array();
        if($clear){
          $arr=array();
        }
        foreach ($data as $k => $v) {
            if($v['pid']==$cateid){
                $arr[]=$v['id'];
                $this->_childrenids($data,$v['id']);
            }
        }
        return $arr;
   }

    // 获取下一级子类的id
    public function sonids($cateid,$obj,$where=[]){
        $data=$obj->field('id,pid')->where($where)->order('sort desc')->select();
        return $this->_getSonids($data,$cateid,TRUE);
    }

    private function _getSonids($data,$cateid,$clear=FALSE){
        static $arr=array();
        if($clear){
            $arr=array();
        }
        foreach ($data as $k => $v) {
            if($v['pid']==$cateid){
                $arr[]=$v['id'];
            }
        }
        return $arr;
    }

   //处理栏目排序
   public function cateSort($reqData,$obj){
        $data = [];
        foreach ($reqData as $k => $v) {
            array_push($data, ['id'=>$k,'sort'=>$v]);
        }
        if(count($data) > 0){
            $obj->saveAll($data);
        }
   }

   //处理批量删除
   public function pdel($cateids){
        foreach ($cateids as $k => $v) {
            $childrenidsarr[]=$this->childrenids($v);
            $childrenidsarr[]=(int)$v;
        }
        $_childrenidsarr=array();
        foreach ($childrenidsarr as $k => $v) {
            if(is_array($v)){
                foreach ($v as $k1 => $v1) {
                   $_childrenidsarr[]=$v1;
                }
            }else{
                $_childrenidsarr[]=$v;
            }
        }
        $_childrenidsarr=array_unique($_childrenidsarr);
        $this::destroy($_childrenidsarr);
   }
}