
<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/2
 * Time: 14:20
 */
return [
    'token_salt'    =>      'SADASSasd2234jkms',
    'pay_back_url'  =>      'https://yue.mgoi.net/api/v1/pay/notify'
];