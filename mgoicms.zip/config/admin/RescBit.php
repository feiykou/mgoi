<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/25
 * Time: 16:55
 */

return [
    1 => '商品',
    2 => '商品分类',
    3 => '主题',
    4 => '文章',
    5 => '礼品分类',
    6 => '礼品分类'
];